<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\Entity;

use App\Entity\Activity;
use App\Entity\Customer;
use App\Entity\Project;
use App\Form\Type\ColorChoiceType;
use App\Form\Type\ColorPickerType;
use App\Form\Type\DurationType;
use App\Form\Type\TagsType;
use App\Form\Type\YesNoType;
use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use KimaiPlugin\MetaFieldsBundle\Form\Type\MetaFieldDatePickerType;
use KimaiPlugin\MetaFieldsBundle\Form\Type\MetaFieldDateTimePickerType;
use KimaiPlugin\MetaFieldsBundle\Form\Type\MetaFieldInvoiceTemplateType;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsRegistry;
use KimaiPlugin\MetaFieldsBundle\Validator\Constraints as Constraints;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\CountryType;
use Symfony\Component\Form\Extension\Core\Type\CurrencyType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\LanguageType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Table(name: 'kimai2_meta_field_rules')]
#[ORM\Index(name: 'meta_field_rule_entity_type_idx', columns: ['entity_type'])]
#[ORM\UniqueConstraint(name: 'meta_field_rule_entity_type_name_uniq', columns: ['entity_type', 'name'])]
#[ORM\Entity(repositoryClass: 'KimaiPlugin\MetaFieldsBundle\Repository\MetaFieldRuleRepository')]
#[UniqueEntity(['name', 'entityType'])]
#[Serializer\ExclusionPolicy('all')]
#[Serializer\VirtualProperty('Customer', exp: 'object.getCustomer() === null ? null : object.getCustomer().getId()', options: [new Serializer\SerializedName('customer'), new Serializer\Type(name: 'integer'), new Serializer\Groups(['Default'])])]
#[Serializer\VirtualProperty('Project', exp: 'object.getProject() === null ? null : object.getProject().getId()', options: [new Serializer\SerializedName('project'), new Serializer\Type(name: 'integer'), new Serializer\Groups(['Default'])])]
#[Serializer\VirtualProperty('Activity', exp: 'object.getActivity() === null ? null : object.getActivity().getId()', options: [new Serializer\SerializedName('activity'), new Serializer\Type(name: 'integer'), new Serializer\Groups(['Default'])])]
#[Constraints\MetaFieldRule]
class MetaFieldRule
{
    public const BOOLEAN_TYPE = 'boolean';
    public const CHOICE_TYPE = 'choice';
    public const CHOICE_SEARCH = 'choice-search';
    public const CHOICE_TYPE_MULTIPLE = 'choice-multiple';
    public const TAGS_TYPE = 'tags';
    public const TAGS_TYPE_TIMESHEET = 'auto-tags';

    /**
     * Unique custom rule ID
     */
    #[ORM\Column(name: 'id', type: 'integer')]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    private ?int $id = null;
    /**
     * The rule is meant for this entity type (e.g. user, customer)
     * @var class-string
     */
    #[ORM\Column(name: 'entity_type', type: 'string', length: 100, nullable: false)]
    #[Assert\NotBlank]
    #[Assert\Length(min: 2, max: 100)]
    private string $entityType;
    /**
     * The internal meta-field name, which is used for access (e.g. in invoice-templates)
     */
    #[ORM\Column(name: 'name', type: 'string', length: 50, nullable: false)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\NotBlank]
    #[Assert\NotNull]
    #[Assert\Length(min: 2, max: 50)]
    private string $name;
    /**
     * The label used to describe the form (input) field
     */
    #[ORM\Column(name: 'label', type: 'string', length: 50, nullable: true)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\Length(max: 50)]
    private ?string $label = null;
    /**
     * A longer and optional help text used to further describe the form field
     */
    #[ORM\Column(name: 'help', type: 'string', length: 200, nullable: true)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\Length(max: 200)]
    private ?string $help = null;
    /**
     * The default value for the meta-field
     */
    #[ORM\Column(name: 'value', type: 'text', nullable: true)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    private ?string $value = null;
    /**
     * The form field type for this rule
     */
    #[ORM\Column(name: 'type', type: 'string', length: 100, nullable: false)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\NotNull]
    #[Assert\NotBlank]
    #[Assert\Length(max: 100)]
    private string $type = 'text';
    /**
     * Restrict the field to the given customer
     */
    #[ORM\ManyToOne(targetEntity: Customer::class)]
    #[ORM\JoinColumn(onDelete: 'CASCADE')]
    private ?Customer $customer = null;
    /**
     * Restrict the field to the given project
     */
    #[ORM\ManyToOne(targetEntity: Project::class)]
    #[ORM\JoinColumn(onDelete: 'CASCADE')]
    private ?Project $project = null;
    /**
     * Restrict the field to the given activity
     */
    #[ORM\ManyToOne(targetEntity: Activity::class)]
    #[ORM\JoinColumn(onDelete: 'CASCADE')]
    private ?Activity $activity = null;
    /**
     * Whether the field is visible in listing views
     */
    #[ORM\Column(name: 'visible', type: 'boolean', nullable: false)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\NotNull]
    private bool $visible = true;
    /**
     * Whether the field is mandatory (true) or optional (false)
     */
    #[ORM\Column(name: 'required', type: 'boolean', nullable: false)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\NotNull]
    private bool $required = false;
    /**
     * Restrict the field to the given permission (can be a role name)
     */
    #[ORM\Column(name: 'permission', type: 'string', length: 100, nullable: true)]
    #[Assert\Length(max: 100)]
    private ?string $permission = null;
    /**
     * For grouping values in separate sections (currently only supported by user-preferences).
     */
    #[ORM\Column(name: 'section', type: 'string', length: 100, nullable: true)]
    #[Assert\Length(max: 100)]
    private ?string $section = null;
    /**
     * Order for the form field
     */
    #[ORM\Column(name: 'weight', type: 'integer', nullable: false, options: ['default' => 0])]
    #[Assert\NotNull]
    private int $weight = 0;

    /**
     * @param class-string $entityType
     */
    public function __construct(string $entityType)
    {
        $this->entityType = $entityType;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function isRuleForUser(): bool
    {
        return $this->entityType === MetaFieldsRegistry::USER_ENTITY;
    }

    /**
     * @return class-string
     */
    public function getEntityType(): string
    {
        return $this->entityType;
    }

    public function isTimesheetRule(): bool
    {
        return $this->entityType === MetaFieldsRegistry::TIMESHEET_ENTITY;
    }

    public function isExpenseRule(): bool
    {
        return $this->entityType === MetaFieldsRegistry::EXPENSE_ENTITY;
    }

    public function isInvoiceRule(): bool
    {
        return $this->entityType === MetaFieldsRegistry::INVOICE_ENTITY;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * Only used in the MetaFieldRuleForm.
     * We cannot use getLabel(), as that displays (if unset) the name and doesn't save if it isn't changed.
     */
    public function setDisplayName(?string $label): void
    {
        $this->label = $label;
    }

    /**
     * Only used in the MetaFieldRuleForm.
     * We cannot use getLabel(), as that displays (if unset) the name and doesn't save if it isn't changed.
     */
    public function getDisplayName(): ?string
    {
        return $this->label;
    }

    public function getLabel(): ?string
    {
        if (empty($this->label)) {
            return $this->name;
        }

        return $this->label;
    }

    public function setLabel(string $label): void
    {
        $this->label = $label;
    }

    public function getHelp(): ?string
    {
        return $this->help;
    }

    public function setHelp(?string $help): void
    {
        $this->help = $help;
    }

    public function getValue(): ?string
    {
        return $this->value;
    }

    public function setValue(?string $value): void
    {
        $this->value = $value;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(string $type): void
    {
        $this->type = $type;
    }

    public function getCustomer(): ?Customer
    {
        return $this->customer;
    }

    public function setCustomer(?Customer $customer): void
    {
        $this->customer = $customer;
    }

    public function getProject(): ?Project
    {
        return $this->project;
    }

    public function setProject(?Project $project): void
    {
        $this->project = $project;
    }

    public function getActivity(): ?Activity
    {
        return $this->activity;
    }

    public function setActivity(?Activity $activity): void
    {
        $this->activity = $activity;
    }

    public function isVisible(): bool
    {
        return $this->visible;
    }

    public function setVisible(bool $visible): void
    {
        $this->visible = $visible;
    }

    public function isRequired(): bool
    {
        return $this->required;
    }

    public function setRequired(bool $required): void
    {
        $this->required = $required;
    }

    public function getPermission(): ?string
    {
        return $this->permission;
    }

    public function setPermission(?string $permission): void
    {
        $this->permission = $permission;
    }

    public function getSection(): ?string
    {
        return $this->section;
    }

    public function setSection(?string $section): void
    {
        $this->section = $section;
    }

    public function getWeight(): int
    {
        return $this->weight;
    }

    public function setWeight(int $weight): void
    {
        $this->weight = $weight;
    }

    /**
     * The rule is meant for this entity type (e.g. user, customer)
     *
     * @return string
     */
    #[Serializer\VirtualProperty]
    #[Serializer\SerializedName('entityType')]
    #[Serializer\Type(name: 'string')]
    #[Serializer\Groups(['Default'])]
    public function getTypeIdentifier(): string
    {
        $values = explode('\\', $this->entityType);

        return strtolower(array_pop($values));
    }

    public function getMappedFieldType(): string
    {
        // before release 1.2 the form type class name was saved in the database
        $type = $this->getType();

        // with >= 1.2 we save only the field alias in the database
        return match ($type) {
            'textarea' => TextareaType::class,
            'email' => EmailType::class,
            'integer' => IntegerType::class,
            'duration' => DurationType::class,
            'money' => MoneyType::class,
            'number' => NumberType::class,
            'boolean' => YesNoType::class,
            'datetime' => MetaFieldDateTimePickerType::class,
            'date' => MetaFieldDatePickerType::class,
            'color' => ColorChoiceType::class,
            'color-free' => ColorPickerType::class,
            'language' => LanguageType::class,
            'country' => CountryType::class,
            'currency' => CurrencyType::class,
            'url' => UrlType::class,
            'invoice-template' => MetaFieldInvoiceTemplateType::class,
            self::CHOICE_TYPE, self::CHOICE_TYPE_MULTIPLE, self::CHOICE_SEARCH => ChoiceType::class,
            self::TAGS_TYPE, self::TAGS_TYPE_TIMESHEET => TagsType::class,
            default => TextType::class,
        };
    }
}
