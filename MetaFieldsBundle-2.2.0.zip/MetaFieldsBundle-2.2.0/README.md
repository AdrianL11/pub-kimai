# Custom-fields plugin for Kimai

Allows configuring additional fields for timesheets, customers, projects, activities, users and expenses.

- Store: [Buy](https://www.kimai.org/store/custom-fields-bundle.html) 
- Documentation: [Custom fields](https://www.kimai.org/documentation/plugin-custom-fields.html). 
- Demo: [Plugins](https://www.kimai.org/demo/).
- Screenshots see [store page](https://www.kimai.org/store/custom-fields-bundle.html)
- Want to extend expenses? Check-out [Expenses Plugin](https://www.kimai.org/store/expenses-bundle.html)

## Compatibility

This plugin is compatible with the following Kimai releases:

| Bundle version | Minimum Kimai version |
|----------------|-----------------------|
| 2.2.0          | 2.1.0                 |
| 2.0 - 2.1.0    | 2.0                   |
| 1.21 - 1.24    | 1.17                  |
| 1.18 - 1.20    | 1.15                  |
| 1.17           | 1.14                  |
| 1.15 - 1.16    | 1.11                  |
| 1.14           | 1.10.2                |
| 1.10 - 1.13    | 1.9                   |
| 1.8 - 1.9      | 1.7                   |
| 1.6 - 1.7      | 1.6.2                 |
| 1.5            | 1.6                   |
| 1.3.2 - 1.4    | 1.4                   |
| 1.1.1 - 1.2    | 1.1                   |
| 1.0            | 1.0                   |

## Installation

Extract the ZIP file and upload the included directory and all files to your Kimai installation to the new directory:  
`var/plugins/MetaFieldsBundle/`

The file structure needs to look like this afterwards:

```bash
var/plugins/
├── MetaFieldsBundle
│   ├── MetaFieldsBundle.php
|   └ ... more files and directories follow here ... 
```

### Clear cache

After uploading the files, Kimai needs to know about the new plugin. It will be found, once the cache was re-built:

```bash
cd kimai2/
bin/console kimai:reload --env=prod
```

### Create database

Run the following command:

```bash
bin/console kimai:bundle:metafields:install
```

This will install all required databases.

### Permissions

This bundle introduces new permissions, which limit access to certain functions:

| Permission Name            | Description                                         |
|----------------------------|-----------------------------------------------------|
| `configure_meta_fields`    | allows to administrate the custom field definitions |

By default, these are assigned to each user with the role `ROLE_SUPER_ADMIN`.

## Updating the plugin

- Delete the directory `var/plugins/MetaFieldsBundle/` (to remove deleted files)
- Execute all installation steps again: unzip rename, clear cache
- Update database with `bin/console kimai:bundle:metafields:install` 
