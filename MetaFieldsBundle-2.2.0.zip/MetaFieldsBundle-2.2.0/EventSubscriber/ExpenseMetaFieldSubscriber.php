<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\EventSubscriber;

use App\Entity\Activity;
use App\Entity\Customer;
use App\Entity\Project;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseMeta;
use KimaiPlugin\ExpensesBundle\Event\ExpenseMetaDefinitionEvent;
use KimaiPlugin\ExpensesBundle\Event\ExpenseMetaDisplayEvent;
use KimaiPlugin\MetaFieldsBundle\Entity\MetaFieldRule;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsRegistry;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class ExpenseMetaFieldSubscriber implements EventSubscriberInterface
{
    public function __construct(private MetaFieldsService $metaFieldsService)
    {
    }

    public static function getSubscribedEvents(): array
    {
        if (!class_exists(MetaFieldsRegistry::EXPENSE_CLASS)) {
            return [];
        }

        return [
            ExpenseMetaDefinitionEvent::class => ['loadExpenseMeta', 200],
            ExpenseMetaDisplayEvent::class => ['loadExpenseFields', 200],
        ];
    }

    private function isRuleForExpense(MetaFieldRule $rule, ?Customer $customer, ?Project $project, ?Activity $activity): bool
    {
        if (!$this->metaFieldsService->canSeeRule($rule)) {
            return false;
        }

        if (null !== $rule->getCustomer() &&
            (
                null === $customer ||
                $rule->getCustomer()->getId() !== $customer->getId()
            )
        ) {
            return false;
        }

        if (null !== $rule->getProject() &&
            (
                null === $project ||
                $rule->getProject()->getId() !== $project->getId()
            )
        ) {
            return false;
        }

        if (null !== $rule->getActivity() &&
            (
                null === $activity ||
                $rule->getActivity()->getId() !== $activity->getId()
            )
        ) {
            return false;
        }

        return true;
    }

    public function loadExpenseMeta(ExpenseMetaDefinitionEvent $event): void
    {
        $entity = $event->getEntity();

        if (\get_class($entity) !== MetaFieldsRegistry::EXPENSE_CLASS) {
            return;
        }

        $rules = $this->metaFieldsService->getRulesForEntityType(MetaFieldsRegistry::EXPENSE_ENTITY);

        if (empty($rules)) {
            return;
        }

        foreach ($rules as $rule) {
            $customer = $entity->getProject() !== null ? $entity->getProject()->getCustomer() : null;

            if (!$this->isRuleForExpense($rule, $customer, $entity->getProject(), $entity->getActivity())) {
                continue;
            }

            $definition = $this->metaFieldsService->getMetaDefinitionForRule(new ExpenseMeta(), $rule);

            if ($definition instanceof ExpenseMeta) {
                $entity->setMetaField($definition);
            }
        }
    }

    public function loadExpenseFields(ExpenseMetaDisplayEvent $event): void
    {
        $rules = $this->metaFieldsService->getRulesForEntityType(MetaFieldsRegistry::EXPENSE_ENTITY);

        if (empty($rules)) {
            return;
        }

        $query = $event->getQuery();

        foreach ($rules as $rule) {
            if (!$rule->isVisible()) {
                continue;
            }

            $customers = $query->getCustomers();
            $customer = null;
            if (\count($customers) === 1) {
                if (\is_int($customers[0])) {
                    continue;
                }
                $customer = $customers[0];
            }

            $projects = $query->getProjects();
            $project = null;
            if (\count($projects) === 1) {
                if (\is_int($projects[0])) {
                    continue;
                }
                $project = $projects[0];
            }

            $activities = $query->getActivities();
            $activity = null;
            if (\count($activities) === 1) {
                $activity = $activities[0];
            }

            if (!$this->isRuleForExpense($rule, $customer, $project, $activity)) {
                continue;
            }

            $event->addField(
                $this->metaFieldsService->getMetaDefinitionForRule(new ExpenseMeta(), $rule)
            );
        }
    }
}
