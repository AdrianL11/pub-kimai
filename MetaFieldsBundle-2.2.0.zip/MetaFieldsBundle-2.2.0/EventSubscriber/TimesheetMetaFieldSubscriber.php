<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\EventSubscriber;

use App\Event\TimesheetMetaDefinitionEvent;
use App\Event\TimesheetMetaDisplayEvent;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class TimesheetMetaFieldSubscriber implements EventSubscriberInterface
{
    public function __construct(private MetaFieldsService $metaFieldsService)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            TimesheetMetaDefinitionEvent::class => ['loadTimesheetMeta', 200],
            TimesheetMetaDisplayEvent::class => ['loadTimesheetFields', 200],
        ];
    }

    public function loadTimesheetMeta(TimesheetMetaDefinitionEvent $event): void
    {
        $this->metaFieldsService->prepareTimesheetMeta($event->getEntity());
    }

    public function loadTimesheetFields(TimesheetMetaDisplayEvent $event): void
    {
        $fields = $this->metaFieldsService->getTimesheetMetaFieldsForQuery($event->getQuery());

        foreach ($fields as $field) {
            $event->addField($field);
        }
    }
}
