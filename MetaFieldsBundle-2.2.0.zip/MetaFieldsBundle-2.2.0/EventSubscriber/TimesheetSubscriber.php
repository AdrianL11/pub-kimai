<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\EventSubscriber;

use App\Entity\EntityWithMetaFields;
use App\Entity\MetaTableTypeInterface;
use App\Entity\Tag;
use App\Entity\Timesheet;
use App\Event\AbstractTimesheetEvent;
use App\Event\TimesheetCreatePreEvent;
use App\Event\TimesheetStopPreEvent;
use App\Event\TimesheetUpdateMultiplePreEvent;
use App\Event\TimesheetUpdatePreEvent;
use App\Repository\TagRepository;
use KimaiPlugin\MetaFieldsBundle\Entity\MetaFieldRule;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsRegistry;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class TimesheetSubscriber implements EventSubscriberInterface
{
    public function __construct(private MetaFieldsService $metaFieldsService, private TagRepository $tagRepository)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            TimesheetUpdatePreEvent::class => ['onTimesheetEvent', -100],
            TimesheetUpdateMultiplePreEvent::class => ['onMultipleTimesheetEvent', -100],
            TimesheetCreatePreEvent::class => ['onTimesheetEvent', -100],
            TimesheetStopPreEvent::class => ['onTimesheetEvent', -100],
        ];
    }

    public function onMultipleTimesheetEvent(TimesheetUpdateMultiplePreEvent $event): void
    {
        foreach ($event->getTimesheets() as $timesheet) {
            $this->updateTimesheet($timesheet);
        }
    }

    public function onTimesheetEvent(AbstractTimesheetEvent $event): void
    {
        $this->updateTimesheet($event->getTimesheet());
    }

    private function updateTimesheet(Timesheet $timesheet): void
    {
        $project = $timesheet->getProject();
        if ($project !== null) {
            $rules = $this->metaFieldsService->getRulesForEntityType(MetaFieldsRegistry::PROJECT_ENTITY);
            $this->handleEntity($timesheet, $project, $rules);

            $customer = $project->getCustomer();
            if ($customer !== null) {
                $rules = $this->metaFieldsService->getRulesForEntityType(MetaFieldsRegistry::CUSTOMER_ENTITY);
                $this->handleEntity($timesheet, $customer, $rules);
            }
        }

        $activity = $timesheet->getActivity();
        if ($activity !== null) {
            $rules = $this->metaFieldsService->getRulesForEntityType(MetaFieldsRegistry::ACTIVITY_ENTITY);
            $this->handleEntity($timesheet, $activity, $rules);
        }
    }

    /**
     * @param Timesheet $timesheet
     * @param EntityWithMetaFields $entityWithMetaFields
     * @param array<MetaFieldRule> $rules
     * @return void
     */
    private function handleEntity(Timesheet $timesheet, EntityWithMetaFields $entityWithMetaFields, array $rules): void
    {
        $names = [];
        foreach ($rules as $rule) {
            if ($rule->getType() === MetaFieldRule::TAGS_TYPE_TIMESHEET) {
                $names[] = $rule->getName();
            }
        }

        foreach ($names as $name) {
            $field = $entityWithMetaFields->getMetaField($name);
            if ($field !== null) {
                $this->handleMeta($timesheet, $field);
            }
        }
    }

    private function handleMeta(Timesheet $timesheet, MetaTableTypeInterface $metaTableType): void
    {
        $value = $metaTableType->getValue();
        if ($value === null) {
            return;
        }

        if (!\is_string($value) || $value === '') {
            return;
        }

        $names = array_filter(explode(',', $value), function ($name) {
            return trim($name) !== '';
        });

        if (\count($names) === 0) {
            return;
        }

        // if we would load only visible tags, we would try to create new ones below
        // and that would trigger the unique constraint
        $tags = $this->tagRepository->findTagsByName($names);

        // if someone deleted the tag since it was saved as configuration, it can be re-created
        // but then: why? it was on purpose ... make this configurable?
        $found = array_map(function (Tag $tag) {
            return $tag->getName();
        }, $tags);

        $missing = array_diff($names, $found);
        foreach ($missing as $newTag) {
            $tag = new Tag();
            $tag->setName(mb_substr($newTag, 0, 100));
            $this->tagRepository->saveTag($tag);
            $tags[] = $tag;
        }

        foreach ($tags as $tag) {
            $timesheet->addTag($tag);
        }
    }
}
