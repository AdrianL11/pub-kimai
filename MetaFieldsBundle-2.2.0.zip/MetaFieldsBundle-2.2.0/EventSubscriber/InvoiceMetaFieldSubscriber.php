<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\EventSubscriber;

use App\Entity\InvoiceMeta;
use App\Event\InvoiceMetaDefinitionEvent;
use App\Event\InvoiceMetaDisplayEvent;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsRegistry;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class InvoiceMetaFieldSubscriber implements EventSubscriberInterface
{
    public function __construct(private MetaFieldsService $metaFieldsService)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            InvoiceMetaDefinitionEvent::class => ['loadInvoiceMeta', 200],
            InvoiceMetaDisplayEvent::class => ['loadInvoiceFields', 200],
        ];
    }

    public function loadInvoiceMeta(InvoiceMetaDefinitionEvent $event): void
    {
        $entity = $event->getEntity();
        $rules = $this->metaFieldsService->getRulesForEntityType(MetaFieldsRegistry::INVOICE_ENTITY);

        if (empty($rules)) {
            return;
        }

        foreach ($rules as $rule) {
            if (!$this->metaFieldsService->canSeeRule($rule)) {
                $entity->getMetaField($rule->getName())?->setIsVisible(false);
                continue;
            }

            $entity->setMetaField(
                $this->metaFieldsService->getMetaDefinitionForRule(new InvoiceMeta(), $rule)
            );
        }
    }

    public function loadInvoiceFields(InvoiceMetaDisplayEvent $event): void
    {
        $rules = $this->metaFieldsService->getRulesForEntityType(MetaFieldsRegistry::INVOICE_ENTITY);

        if (empty($rules)) {
            return;
        }

        foreach ($rules as $rule) {
            if (!$rule->isVisible()) {
                continue;
            }

            if (!$this->metaFieldsService->canSeeRule($rule)) {
                continue;
            }

            $event->addField(
                $this->metaFieldsService->getMetaDefinitionForRule(new InvoiceMeta(), $rule)
            );
        }
    }
}
