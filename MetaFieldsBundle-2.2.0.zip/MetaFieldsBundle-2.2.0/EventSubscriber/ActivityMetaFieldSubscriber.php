<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\EventSubscriber;

use App\Event\ActivityMetaDefinitionEvent;
use App\Event\ActivityMetaDisplayEvent;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class ActivityMetaFieldSubscriber implements EventSubscriberInterface
{
    public function __construct(private MetaFieldsService $metaFieldsService)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            ActivityMetaDefinitionEvent::class => ['loadActivityMeta', 200],
            ActivityMetaDisplayEvent::class => ['loadActivityFields', 200],
        ];
    }

    public function loadActivityMeta(ActivityMetaDefinitionEvent $event): void
    {
        $this->metaFieldsService->prepareActivityMeta($event->getEntity());
    }

    public function loadActivityFields(ActivityMetaDisplayEvent $event): void
    {
        $fields = $this->metaFieldsService->getActivityMetaFieldsForQuery($event->getQuery());

        foreach ($fields as $field) {
            $event->addField($field);
        }
    }
}
