<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\EventSubscriber;

use App\Entity\CustomerMeta;
use App\Event\CustomerMetaDefinitionEvent;
use App\Event\CustomerMetaDisplayEvent;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsRegistry;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class CustomerMetaFieldSubscriber implements EventSubscriberInterface
{
    public function __construct(private MetaFieldsService $metaFieldsService)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CustomerMetaDefinitionEvent::class => ['loadCustomerMeta', 200],
            CustomerMetaDisplayEvent::class => ['loadCustomerFields', 200],
        ];
    }

    public function loadCustomerMeta(CustomerMetaDefinitionEvent $event): void
    {
        $this->metaFieldsService->prepareCustomerMeta($event->getEntity());
    }

    public function loadCustomerFields(CustomerMetaDisplayEvent $event): void
    {
        $rules = $this->metaFieldsService->getRulesForEntityType(MetaFieldsRegistry::CUSTOMER_ENTITY);

        if (empty($rules)) {
            return;
        }

        foreach ($rules as $rule) {
            if (!$rule->isVisible()) {
                continue;
            }

            if (!$this->metaFieldsService->canSeeRule($rule)) {
                continue;
            }

            $event->addField(
                $this->metaFieldsService->getMetaDefinitionForRule(new CustomerMeta(), $rule)
            );
        }
    }
}
