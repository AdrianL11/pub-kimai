<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\EventSubscriber;

use App\Entity\UserPreference;
use App\Event\UserPreferenceDisplayEvent;
use App\Event\UserPreferenceEvent;
use KimaiPlugin\MetaFieldsBundle\Entity\MetaFieldRule;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsRegistry;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class UserPreferenceSubscriber implements EventSubscriberInterface
{
    public function __construct(private MetaFieldsService $metaFieldsService)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            UserPreferenceEvent::class => ['loadUserPreferences', 200],
            UserPreferenceDisplayEvent::class => ['loadUserFields', 200],
        ];
    }

    public function loadUserPreferences(UserPreferenceEvent $event): void
    {
        $preferences = $this->getUserPreferences(false);

        foreach ($preferences as $preference) {
            try {
                $event->addPreference($preference);
            } catch (\Exception $ex) {
                // we have to ignore that, it could lead to an unfixable 500 error
            }
        }
    }

    public function loadUserFields(UserPreferenceDisplayEvent $event): void
    {
        $preferences = $this->getUserPreferences(true);

        foreach ($preferences as $preference) {
            $event->addPreference($preference);
        }
    }

    /**
     * @param bool $onlyVisible
     * @return array<UserPreference>
     */
    private function getUserPreferences(bool $onlyVisible = false): array
    {
        $rules = $this->metaFieldsService->getRulesForEntityType(MetaFieldsRegistry::USER_ENTITY);

        $preferences = [];

        foreach ($rules as $rule) {
            if ($onlyVisible && !$rule->isVisible()) {
                continue;
            }

            if (!$this->metaFieldsService->canSeeRule($rule)) {
                continue;
            }

            $pref = $this->getPreferenceFromRule($rule);

            $preferences[] = $pref;
        }

        return $preferences;
    }

    private function getPreferenceFromRule(MetaFieldRule $rule): UserPreference
    {
        $options = ['label' => $rule->getLabel()];
        $value = $rule->getValue();

        if ($rule->getType() === MetaFieldRule::CHOICE_TYPE) {
            $options['choices'] = $this->metaFieldsService->getChoicesFromRule($rule);
            $options['search'] = false;
            $value = null;
        } elseif ($rule->getType() === MetaFieldRule::CHOICE_SEARCH) {
            $options['choices'] = $this->metaFieldsService->getChoicesFromRule($rule);
            $options['search'] = true;
            $value = null;
        } elseif ($rule->getType() === MetaFieldRule::CHOICE_TYPE_MULTIPLE) {
            $options['choices'] = $this->metaFieldsService->getChoicesFromRule($rule);
            $options['multiple'] = true;
            $options['expanded'] = false;
            $options['search'] = false;
            $value = null;
        } elseif ($rule->getType() === MetaFieldRule::BOOLEAN_TYPE) {
            $value = (bool) $value;
        }

        if (!$rule->isRequired()) {
            $options['required'] = false;
        }

        if (!empty($rule->getHelp())) {
            $options['help'] = $rule->getHelp();
        }

        $preference = new UserPreference($rule->getName(), $value);
        $preference
            ->setType($rule->getMappedFieldType())
            ->setOptions($options)
            ->setOrder($rule->getWeight() + 1000)
            ->setSection($rule->getSection() ?? 'Custom fields')
        ;

        return $preference;
    }
}
