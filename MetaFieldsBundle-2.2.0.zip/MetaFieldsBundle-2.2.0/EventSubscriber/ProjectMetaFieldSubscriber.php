<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\EventSubscriber;

use App\Event\ProjectMetaDefinitionEvent;
use App\Event\ProjectMetaDisplayEvent;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class ProjectMetaFieldSubscriber implements EventSubscriberInterface
{
    public function __construct(private MetaFieldsService $metaFieldsService)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            ProjectMetaDefinitionEvent::class => ['loadProjectMeta', 200],
            ProjectMetaDisplayEvent::class => ['loadProjectFields', 200],
        ];
    }

    public function loadProjectMeta(ProjectMetaDefinitionEvent $event): void
    {
        $this->metaFieldsService->prepareProjectMeta($event->getEntity());
    }

    public function loadProjectFields(ProjectMetaDisplayEvent $event): void
    {
        $fields = $this->metaFieldsService->getProjectMetaFieldsForQuery($event->getQuery());

        foreach ($fields as $field) {
            $event->addField($field);
        }
    }
}
