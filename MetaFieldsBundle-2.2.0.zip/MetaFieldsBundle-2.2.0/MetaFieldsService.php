<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle;

use App\Entity\Activity;
use App\Entity\ActivityMeta;
use App\Entity\Customer;
use App\Entity\CustomerMeta;
use App\Entity\MetaTableTypeInterface;
use App\Entity\Project;
use App\Entity\ProjectMeta;
use App\Entity\Timesheet;
use App\Entity\TimesheetMeta;
use App\Repository\Query\ActivityQuery;
use App\Repository\Query\ProjectQuery;
use App\Repository\Query\TimesheetQuery;
use KimaiPlugin\MetaFieldsBundle\Entity\MetaFieldRule;
use KimaiPlugin\MetaFieldsBundle\Repository\MetaFieldRuleRepository;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\Validator\Constraints\Length;

final class MetaFieldsService
{
    /**
     * @var array<string, array<MetaFieldRule>>
     */
    private array $rulesCache = [];

    public function __construct(private MetaFieldRuleRepository $repository, private Security $security)
    {
    }

    private function clearCache(): void
    {
        $this->rulesCache = [];
    }

    public function saveRule(MetaFieldRule $rule): void
    {
        $this->repository->saveRule($rule);
        $this->clearCache();
    }

    public function deleteRule(MetaFieldRule $rule): void
    {
        $this->repository->deleteRule($rule);
        $this->clearCache();
    }

    public function countRuleUsages(MetaFieldRule $rule): int
    {
        return $this->repository->countRuleUsages($rule);
    }

    /**
     * @return MetaFieldRule[]
     */
    public function getRules(): array
    {
        return $this->repository->getRules();
    }

    public function canSeeRule(MetaFieldRule $rule): bool
    {
        if (empty($rule->getPermission())) {
            return true;
        }

        if ($this->security->getUser() === null) {
            // command line export / invoice
            return true;
        }

        return $this->security->isGranted($rule->getPermission());
    }

    /**
     * @param string $entityType
     * @return MetaFieldRule[]
     */
    public function getRulesForEntityType(string $entityType): array
    {
        if (!\array_key_exists($entityType, $this->rulesCache)) {
            foreach (MetaFieldsRegistry::getAllEntityTypes() as $type) {
                $this->rulesCache[$type] = [];
            }
            $rules = $this->getRules();
            foreach ($rules as $rule) {
                $this->rulesCache[$rule->getEntityType()][] = $rule;
            }
        }

        return $this->rulesCache[$entityType];
    }

    /**
     * @param MetaFieldRule $rule
     * @return array<string, string>
     */
    public function getChoicesFromRule(MetaFieldRule $rule): array
    {
        $value = $rule->getValue();
        if ($value === null) {
            return [];
        }

        $choices = [];

        foreach (explode(',', $value) as $choice) {
            $choice = trim($choice);
            $choice = explode('|', $choice);
            if (\count($choice) === 1) {
                $choices[$choice[0]] = $choice[0];
            } else {
                $choices[$choice[1]] = $choice[0];
            }
        }

        return $choices;
    }

    public function getMetaDefinitionForRule(MetaTableTypeInterface $type, MetaFieldRule $rule): MetaTableTypeInterface
    {
        $options = ['label' => $rule->getLabel()];

        $value = $rule->getValue();

        if ($rule->getType() === MetaFieldRule::CHOICE_TYPE) {
            $options['choices'] = $this->getChoicesFromRule($rule);
            $options['search'] = false;
            $value = null;
        } elseif ($rule->getType() === MetaFieldRule::CHOICE_SEARCH) {
            $options['choices'] = $this->getChoicesFromRule($rule);
            $options['search'] = true;
            $value = null;
        } elseif ($rule->getType() === MetaFieldRule::CHOICE_TYPE_MULTIPLE) {
            $options['choices'] = $this->getChoicesFromRule($rule);
            $options['multiple'] = true;
            $options['expanded'] = false;
            $options['search'] = false;
            $value = null;
        } elseif ($rule->getType() === MetaFieldRule::BOOLEAN_TYPE) {
            $value = (bool) $value;
        } elseif ($rule->getType() === MetaFieldRule::TAGS_TYPE_TIMESHEET) {
            if (empty($rule->getHelp())) {
                $options['help'] = 'help.auto-tags';
            }
        }

        if (!empty($rule->getHelp())) {
            $options['help'] = $rule->getHelp();
        }

        $type->setName($rule->getName());
        $type->setType($rule->getMappedFieldType());
        $type->setIsVisible($rule->isVisible());
        $type->setIsRequired($rule->isRequired());
        $type->setLabel($rule->getLabel());
        $type->setOptions($options);
        $type->setValue($value);
        $type->setOrder($rule->getWeight());
        $type->setConstraints([
            // meta fields are limited to 65535 characters
            new Length(['min' => 0, 'max' => 65535])
        ]);

        return $type;
    }

    // ---------------------------- TIMESHEET ----------------------------

    private function isRuleForTimesheet(MetaFieldRule $rule, ?Customer $customer, ?Project $project, ?Activity $activity): bool
    {
        if (!$this->canSeeRule($rule)) {
            return false;
        }

        if (null !== $rule->getCustomer() &&
            (
                null === $customer ||
                $rule->getCustomer()->getId() !== $customer->getId()
            )
        ) {
            return false;
        }

        if (null !== $rule->getProject() &&
            (
                null === $project ||
                $rule->getProject()->getId() !== $project->getId()
            )
        ) {
            return false;
        }

        if (null !== $rule->getActivity() &&
            (
                null === $activity ||
                $rule->getActivity()->getId() !== $activity->getId()
            )
        ) {
            return false;
        }

        return true;
    }

    public function prepareTimesheetMeta(Timesheet $entity): void
    {
        $rules = $this->getRulesForEntityType(MetaFieldsRegistry::TIMESHEET_ENTITY);

        if (empty($rules)) {
            return;
        }

        foreach ($rules as $rule) {
            $customer = $entity->getProject()?->getCustomer();

            if (!$this->isRuleForTimesheet($rule, $customer, $entity->getProject(), $entity->getActivity())) {
                continue;
            }

            $entity->setMetaField(
                $this->getMetaDefinitionForRule(new TimesheetMeta(), $rule)
            );
        }
    }

    /**
     * @param TimesheetQuery $query
     * @return array<MetaTableTypeInterface>
     */
    public function getTimesheetMetaFieldsForQuery(TimesheetQuery $query): array
    {
        $rules = $this->getRulesForEntityType(MetaFieldsRegistry::TIMESHEET_ENTITY);

        $visible = [];
        foreach ($rules as $rule) {
            if (!$rule->isVisible()) {
                continue;
            }

            $customers = $query->getCustomers();
            $customer = \count($customers) === 1 ? $customers[0] : null;

            $projects = $query->getProjects();
            $project = \count($projects) === 1 ? $projects[0] : null;

            $activities = $query->getActivities();
            $activity = \count($activities) === 1 ? $activities[0] : null;

            if (!$this->isRuleForTimesheet($rule, $customer, $project, $activity)) {
                continue;
            }

            $visible[] = $this->getMetaDefinitionForRule(new TimesheetMeta(), $rule);
        }

        return $visible;
    }

    // ---------------------------- CUSTOMER ----------------------------

    public function prepareCustomerMeta(Customer $entity): void
    {
        $rules = $this->getRulesForEntityType(MetaFieldsRegistry::CUSTOMER_ENTITY);

        if (empty($rules)) {
            return;
        }

        foreach ($rules as $rule) {
            if (!$this->canSeeRule($rule)) {
                $entity->getMetaField($rule->getName())?->setIsVisible(false);
                continue;
            }

            $entity->setMetaField(
                $this->getMetaDefinitionForRule(new CustomerMeta(), $rule)
            );
        }
    }

    // ---------------------------- PROJECT ----------------------------

    private function isRuleForProject(MetaFieldRule $rule, ?Customer $customer): bool
    {
        if (!$this->canSeeRule($rule)) {
            return false;
        }

        if (null !== $rule->getCustomer() &&
            (
                null === $customer ||
                $rule->getCustomer()->getId() !== $customer->getId()
            )
        ) {
            return false;
        }

        return true;
    }

    public function prepareProjectMeta(Project $entity): void
    {
        $rules = $this->getRulesForEntityType(MetaFieldsRegistry::PROJECT_ENTITY);

        if (empty($rules)) {
            return;
        }

        foreach ($rules as $rule) {
            if (!$this->isRuleForProject($rule, $entity->getCustomer())) {
                $entity->getMetaField($rule->getName())?->setIsVisible(false);
                continue;
            }

            $entity->setMetaField(
                $this->getMetaDefinitionForRule(new ProjectMeta(), $rule)
            );
        }
    }

    /**
     * @param ProjectQuery $query
     * @return array<MetaTableTypeInterface>
     */
    public function getProjectMetaFieldsForQuery(ProjectQuery $query): array
    {
        $rules = $this->getRulesForEntityType(MetaFieldsRegistry::PROJECT_ENTITY);

        $visible = [];
        foreach ($rules as $rule) {
            if (!$rule->isVisible()) {
                continue;
            }

            $customers = $query->getCustomers();
            $customer = \count($customers) === 1 ? $customers[0] : null;

            if (!$this->isRuleForProject($rule, $customer)) {
                continue;
            }

            $visible[] = $this->getMetaDefinitionForRule(new ProjectMeta(), $rule);
        }

        return $visible;
    }

    // ---------------------------- ACTIVITY ----------------------------

    private function isRuleForActivity(MetaFieldRule $rule, ?Customer $customer, ?Project $project): bool
    {
        if (!$this->canSeeRule($rule)) {
            return false;
        }

        if (null !== $rule->getCustomer() &&
            (
                null === $customer ||
                $rule->getCustomer()->getId() !== $customer->getId()
            )
        ) {
            return false;
        }

        if (null !== $rule->getProject() &&
            (
                null === $project ||
                $rule->getProject()->getId() !== $project->getId()
            )
        ) {
            return false;
        }

        return true;
    }

    public function prepareActivityMeta(Activity $entity): void
    {
        $rules = $this->getRulesForEntityType(MetaFieldsRegistry::ACTIVITY_ENTITY);

        if (empty($rules)) {
            return;
        }

        foreach ($rules as $rule) {
            $customer = $entity->getProject()?->getCustomer();
            if (!$this->isRuleForActivity($rule, $customer, $entity->getProject())) {
                $entity->getMetaField($rule->getName())?->setIsVisible(false);
                continue;
            }

            $entity->setMetaField(
                $this->getMetaDefinitionForRule(new ActivityMeta(), $rule)
            );
        }
    }

    /**
     * @param ActivityQuery $query
     * @return array<MetaTableTypeInterface>
     */
    public function getActivityMetaFieldsForQuery(ActivityQuery $query): array
    {
        $rules = $this->getRulesForEntityType(MetaFieldsRegistry::ACTIVITY_ENTITY);

        $visible = [];
        foreach ($rules as $rule) {
            if (!$rule->isVisible()) {
                continue;
            }

            $customers = $query->getCustomers();
            $customer = \count($customers) === 1 ? $customers[0] : null;

            $projects = $query->getProjects();
            $project = \count($projects) === 1 ? $projects[0] : null;

            if (!$this->isRuleForActivity($rule, $customer, $project)) {
                continue;
            }

            $visible[] = $this->getMetaDefinitionForRule(new ActivityMeta(), $rule);
        }

        return $visible;
    }
}
