<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\API;

use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\View\View;
use FOS\RestBundle\View\ViewHandlerInterface;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsRegistry;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsService;
use KimaiPlugin\MetaFieldsBundle\Validator\Constraints\MetaFieldExternalType;
use Nelmio\ApiDocBundle\Annotation\Security as ApiSecurity;
use OpenApi\Attributes as OA;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

#[OA\Tag(name: 'MetaField')]
final class MetaFieldsController
{
    public function __construct(private ViewHandlerInterface $viewHandler, private MetaFieldsService $service, private AuthorizationCheckerInterface $security)
    {
    }

    /**
     * Returns a collection of meta-fields
     */
    #[OA\Response(response: 200, description: 'Returns a collection of meta-fields', content: new OA\JsonContent(type: 'array', items: new OA\Items(ref: '#/components/schemas/MetaFieldRule')))]
    #[Rest\QueryParam(name: 'entity', requirements: [new MetaFieldExternalType()], strict: true, nullable: true, description: 'The type of object to fetch meta-fields for. Allowed values: timesheet, customer, project, activity, user, expense, invoice - returns all if not given (default: all)')]
    #[Rest\Get(path: '/metafields')]
    #[ApiSecurity(name: 'apiUser')]
    #[ApiSecurity(name: 'apiToken')]
    public function cgetAction(ParamFetcherInterface $paramFetcher): Response
    {
        $entityType = null;

        $type = $paramFetcher->get('entity');
        if (null !== $type && \is_string($type)) {
            $entityType = MetaFieldsRegistry::mapExternalNameToEntityType($type);
        }

        if (null === $entityType) {
            $rules = $this->service->getRules();
        } else {
            $rules = $this->service->getRulesForEntityType($entityType);
        }

        $data = [];
        foreach ($rules as $rule) {
            if ($rule->getPermission() !== null && !$this->security->isGranted($rule->getPermission())) {
                continue;
            }
            $data[] = $rule;
        }

        $view = new View($data, 200);
        $view->getContext()->setGroups(['Default', 'Collection', 'MetaField']);

        return $this->viewHandler->handle($view);
    }
}
