<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\DependencyInjection;

use KimaiPlugin\MetaFieldsBundle\EventSubscriber\ExpenseMetaFieldSubscriber;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Extension\PrependExtensionInterface;
use Symfony\Component\DependencyInjection\Loader;
use Symfony\Component\HttpKernel\DependencyInjection\Extension;
use Symfony\Component\Yaml\Parser;

final class MetaFieldsExtension extends Extension implements PrependExtensionInterface
{
    public function load(array $configs, ContainerBuilder $container): void
    {
        if ('test' === $container->getParameter('kernel.environment')) {
            return;
        }

        $loader = new Loader\YamlFileLoader($container, new FileLocator(__DIR__ . '/../Resources/config'));
        $loader->load('services.yaml');

        /** @var array<string> $bundles */
        $bundles = $container->getParameter('kernel.bundles');

        if (!isset($bundles['ExpensesBundle'])) {
            $container->removeDefinition(ExpenseMetaFieldSubscriber::class);
        }
    }

    public function prepend(ContainerBuilder $container): void
    {
        $yamlParser = new Parser();

        $config = $yamlParser->parseFile(__DIR__ . '/../Resources/config/packages/nelmio_api_doc.yaml');
        if (\is_array($config) && \array_key_exists('nelmio_api_doc', $config) && \is_array($config['nelmio_api_doc'])) {
            $container->prependExtensionConfig('nelmio_api_doc', $config['nelmio_api_doc']); // @phpstan-ignore-line
        }

        $container->prependExtensionConfig('kimai', [
            'permissions' => [
                'roles' => [
                    'ROLE_SUPER_ADMIN' => [
                        'configure_meta_fields',
                    ],
                ],
            ],
        ]);

        $container->prependExtensionConfig('jms_serializer', [
            'metadata' => [
                'warmup' => [
                    'paths' => [
                        'included' => [
                            __DIR__ . '/../Entity/'
                        ],
                    ],
                ],
            ],
        ]);
    }
}
