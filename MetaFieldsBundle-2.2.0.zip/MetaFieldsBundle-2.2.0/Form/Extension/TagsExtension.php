<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\Form\Extension;

use App\Entity\MetaTableTypeInterface;
use App\Entity\Tag;
use App\Form\ActivityEditForm;
use App\Form\CustomerEditForm;
use App\Form\ProjectEditForm;
use App\Form\Type\TagsType;
use App\Repository\TagRepository;
use Doctrine\Common\Collections\Collection;
use Symfony\Component\Form\AbstractTypeExtension;
use Symfony\Component\Form\CallbackTransformer;
use Symfony\Component\Form\FormBuilderInterface;

class TagsExtension extends AbstractTypeExtension
{
    public function __construct(private TagRepository $tagRepository)
    {
    }

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        if (!$builder->has('metaFields')) {
            return;
        }

        $metas = $builder->get('metaFields');
        $metas->addModelTransformer(new CallbackTransformer(
            function (Collection $transform) {
                /** @var MetaTableTypeInterface $item */
                foreach ($transform as $item) {
                    if ($item->getType() === TagsType::class) {
                        if (\is_string($item->getValue())) {
                            $tags = explode(',', $item->getValue());
                            // only add non-hidden tags
                            $item->setValue($this->tagRepository->findTagsByName($tags, true));
                        }
                    }
                }

                return $transform;
            },
            function ($reverseTransform) {
                /** @var MetaTableTypeInterface $item */
                foreach ($reverseTransform as $item) {
                    if ($item->getType() === TagsType::class) {
                        /** @var Collection<Tag> $tags */
                        $tags = $item->getValue();
                        $values = array_map(function (Tag $tag) { // @phpstan-ignore-line
                            if ($tag->getId() === null) {
                                $this->tagRepository->saveTag($tag);
                            }

                            return $tag->getName();
                        }, $tags->toArray());
                        $item->setValue(implode(',', $values));
                    }
                }

                return $reverseTransform;
            }
        ));
    }

    public static function getExtendedTypes(): iterable
    {
        return [
            CustomerEditForm::class,
            ProjectEditForm::class,
            ActivityEditForm::class,
        ];
    }
}
