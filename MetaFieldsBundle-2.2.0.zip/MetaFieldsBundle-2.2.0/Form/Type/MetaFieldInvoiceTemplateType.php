<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\Form\Type;

use App\Entity\InvoiceTemplate;
use App\Form\Type\InvoiceTemplateType as BaseInvoiceTemplateType;
use App\Repository\InvoiceTemplateRepository;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class MetaFieldInvoiceTemplateType extends AbstractType implements DataTransformerInterface
{
    public function __construct(private InvoiceTemplateRepository $invoiceTemplateRepository)
    {
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'help' => null
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->addModelTransformer($this);
    }

    /**
     * @param mixed $value
     * @return InvoiceTemplate|int|mixed|object
     */
    public function transform($value): mixed
    {
        if (empty($value)) {
            return $value;
        }

        if ($value instanceof InvoiceTemplate) {
            return $value;
        }

        if (\is_string($value) || \is_int($value)) {
            $value = (int) $value;
            $tpl = $this->invoiceTemplateRepository->find($value);
            if (null !== $tpl) {
                return $tpl;
            }
        }

        return $value;
    }

    /**
     * @param mixed $value
     * @return int|mixed|null
     */
    public function reverseTransform($value): mixed
    {
        if ($value instanceof InvoiceTemplate) {
            return $value->getId();
        }

        return $value;
    }

    public function getParent(): string
    {
        return BaseInvoiceTemplateType::class;
    }
}
