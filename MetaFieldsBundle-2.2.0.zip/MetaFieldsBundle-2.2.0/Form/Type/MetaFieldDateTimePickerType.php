<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\Form\Type;

use App\Form\Type\DateTimePickerType as CoreDateTimePickerType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\DataTransformer\DateTimeToStringTransformer;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\ReversedTransformer;

/**
 * Custom form field type to display the date input fields.
 */
class MetaFieldDateTimePickerType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->addModelTransformer(new ReversedTransformer(new DateTimeToStringTransformer()));
    }

    public function getParent(): string
    {
        return CoreDateTimePickerType::class;
    }
}
