<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\Form\Type;

use App\Entity\Activity;
use App\Entity\Customer;
use App\Entity\Project;
use KimaiPlugin\MetaFieldsBundle\Entity\MetaFieldRule;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\OptionsResolver\Options;
use Symfony\Component\OptionsResolver\OptionsResolver;

class MetaFieldRuleEntityInputType extends AbstractType
{
    public const VALID_INPUTS = [
        'type.text' => 'text',
        'type.textarea' => 'textarea',
        'type.integer' => 'integer',
        'type.email' => 'email',
        'type.url' => 'url',
        'type.duration' => 'duration',
        'type.money' => 'money',
        'type.number' => 'number',
        'type.boolean' => 'boolean',
        'type.datetime' => 'datetime',
        'type.date' => 'date',
        'type.invoice-template' => 'invoice-template',
        'type.choice' => MetaFieldRule::CHOICE_TYPE,
        'type.choice-search' => MetaFieldRule::CHOICE_SEARCH,
        'type.color' => 'color',
        'type.color-free' => 'color-free',
        'type.language' => 'language',
        'type.country' => 'country',
        'type.currency' => 'currency',
        // doesn't work by now:
        // needs refactoring (or a new formtype that converts an array to json or a comma separated list, to store it in the db field) in kimai core
        //'choice-list-multiple' => MetaFieldRule::CHOICE_TYPE_MULTIPLE,
    ];

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'label' => 'entityType',
            'entityType' => null,
        ]);

        // which field types are available in which item types
        $resolver->setDefault('choices', function (Options $options) {
            $choices = self::VALID_INPUTS;

            switch ($options['entityType']) {
                case Customer::class:
                case Project::class:
                case Activity::class:
                    //$choices['tags'] = MetaFieldRule::TAGS_TYPE;
                    $choices['type.auto-tags'] = MetaFieldRule::TAGS_TYPE_TIMESHEET;
                    break;
            }

            return $choices;
        });
    }

    public function getParent(): ?string
    {
        return ChoiceType::class;
    }
}
