<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle;

use App\Entity\Activity;
use App\Entity\ActivityMeta;
use App\Entity\Customer;
use App\Entity\CustomerMeta;
use App\Entity\Invoice;
use App\Entity\InvoiceMeta;
use App\Entity\Project;
use App\Entity\ProjectMeta;
use App\Entity\Timesheet;
use App\Entity\TimesheetMeta;
use App\Entity\User;
use App\Entity\UserPreference;

/**
 * All the PHPStan ignores are here, due to the Expense classes, which are not available in CI
 */
final class MetaFieldsRegistry
{
    // All ENTITY_* constants represent the value of the database column "entity_type"
    /** @var class-string */
    public const EXPENSE_ENTITY = 'KimaiPlugin\ExpensesBundle\Entity\Expense'; // @phpstan-ignore-line
    /** @var class-string */
    public const TIMESHEET_ENTITY = Timesheet::class;
    /** @var class-string */
    public const CUSTOMER_ENTITY = Customer::class;
    /** @var class-string */
    public const PROJECT_ENTITY = Project::class;
    /** @var class-string */
    public const ACTIVITY_ENTITY = Activity::class;
    /** @var class-string */
    public const USER_ENTITY = User::class;
    /** @var class-string */
    public const INVOICE_ENTITY = Invoice::class;

    // All CLASS_* constants represent the value of the real entity class
    /** @var class-string */
    public const EXPENSE_CLASS = 'KimaiPlugin\ExpensesBundle\Entity\Expense'; // @phpstan-ignore-line
    /** @var class-string */
    public const TIMESHEET_CLASS = Timesheet::class;
    /** @var class-string */
    public const CUSTOMER_CLASS = Customer::class;
    /** @var class-string */
    public const PROJECT_CLASS = Project::class;
    /** @var class-string */
    public const ACTIVITY_CLASS = Activity::class;
    /** @var class-string */
    public const USER_CLASS = User::class;
    /** @var class-string */
    public const INVOICE_CLASS = Invoice::class;

    // External mapping names for forms and request parameter
    public const EXPENSE = 'expense';
    public const TIMESHEET = 'timesheet';
    public const CUSTOMER = 'customer';
    public const PROJECT = 'project';
    public const ACTIVITY = 'activity';
    public const USER = 'user';
    public const INVOICE = 'invoice';

    /** @var class-string */
    public const EXPENSE_META = 'KimaiPlugin\ExpensesBundle\Entity\ExpenseMeta'; // @phpstan-ignore-line
    /** @var class-string */
    public const TIMESHEET_META = TimesheetMeta::class;
    /** @var class-string */
    public const CUSTOMER_META = CustomerMeta::class;
    /** @var class-string */
    public const PROJECT_META = ProjectMeta::class;
    /** @var class-string */
    public const ACTIVITY_META = ActivityMeta::class;
    /** @var class-string */
    public const USER_META = UserPreference::class;
    /** @var class-string */
    public const INVOICE_META = InvoiceMeta::class;

    /**
     * @var array<string, class-string>
     */
    private const EXTERNAL_TO_ENTITY = [ // @phpstan-ignore-line
        self::TIMESHEET => self::TIMESHEET_ENTITY,
        self::CUSTOMER => self::CUSTOMER_ENTITY,
        self::PROJECT => self::PROJECT_ENTITY,
        self::ACTIVITY => self::ACTIVITY_ENTITY,
        self::USER => self::USER_ENTITY,
        self::EXPENSE => self::EXPENSE_ENTITY,
        self::INVOICE => self::INVOICE_ENTITY,
    ];

    /**
     * @var array<class-string, class-string>
     */
    private const ENTITY_TO_META = [ // @phpstan-ignore-line
        self::TIMESHEET_ENTITY => self::TIMESHEET_META,
        self::CUSTOMER_ENTITY => self::CUSTOMER_META,
        self::PROJECT_ENTITY => self::PROJECT_META,
        self::ACTIVITY_ENTITY => self::ACTIVITY_META,
        self::USER_ENTITY => self::USER_META,
        self::EXPENSE_ENTITY => self::EXPENSE_META,
        self::INVOICE_ENTITY => self::INVOICE_META,
    ];

    /**
     * @var array<class-string, string>
     */
    private const ENTITY_TO_TITLE = [ // @phpstan-ignore-line
        self::TIMESHEET_ENTITY => 'time_tracking',
        self::CUSTOMER_ENTITY => 'customer',
        self::PROJECT_ENTITY => 'project',
        self::ACTIVITY_ENTITY => 'activity',
        self::USER_ENTITY => 'user',
        self::EXPENSE_ENTITY => 'Expenses',
        self::INVOICE_ENTITY => 'invoices',
    ];

    /**
     * @param string $external
     * @return class-string
     */
    public static function mapExternalNameToEntityType(string $external): string
    {
        if (!\array_key_exists($external, self::EXTERNAL_TO_ENTITY)) {
            throw new \InvalidArgumentException('Unknown entity type by external: ' . $external);
        }

        return self::EXTERNAL_TO_ENTITY[$external]; // @phpstan-ignore-line
    }

    public static function mapEntityTypeToExternalName(string $entity): string
    {
        $values = array_flip(self::EXTERNAL_TO_ENTITY);
        if (!\array_key_exists($entity, $values)) {
            throw new \InvalidArgumentException('Unknown external name by entity type: ' . $entity);
        }

        return $values[$entity];
    }

    /**
     * @return array<string>
     */
    public static function getAllExternalNames(): array
    {
        return array_keys(self::EXTERNAL_TO_ENTITY);
    }

    /**
     * @return array<int, class-string>
     */
    public static function getAllEntityTypes(): array
    {
        return array_keys(self::ENTITY_TO_META); // @phpstan-ignore-line
    }

    /**
     * @param class-string $entityType
     * @return class-string
     */
    public static function mapEntityTypeToMetaClass(string $entityType): string
    {
        if (!\array_key_exists($entityType, self::ENTITY_TO_META)) {
            throw new \InvalidArgumentException('Unknown entity type for meta: ' . $entityType);
        }

        return self::ENTITY_TO_META[$entityType];
    }

    public static function mapEntityTypeToTitle(string $entityType): string
    {
        if (!\array_key_exists($entityType, self::ENTITY_TO_TITLE)) {
            throw new \InvalidArgumentException('Unknown entity type for title: ' . $entityType);
        }

        return self::ENTITY_TO_TITLE[$entityType];
    }
}
