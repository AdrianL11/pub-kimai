<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

#[\Attribute(\Attribute::TARGET_CLASS)]
class MetaFieldRule extends Constraint
{
    public const ALREADY_IN_USE = 'kimai-meta-field-01';

    /**
     * @var array<string, string>
     */
    protected const ERROR_NAMES = [
        self::ALREADY_IN_USE => 'This name is already in use, please choose another one.',
    ];

    public string $message = 'This custom field has invalid settings.';

    public function getTargets(): string|array
    {
        return self::CLASS_CONSTRAINT;
    }
}
