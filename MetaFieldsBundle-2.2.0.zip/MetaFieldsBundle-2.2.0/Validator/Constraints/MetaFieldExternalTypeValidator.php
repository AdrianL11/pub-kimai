<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\Validator\Constraints;

use KimaiPlugin\MetaFieldsBundle\Entity\MetaFieldRule as MetaFieldRuleEntity;
use KimaiPlugin\MetaFieldsBundle\MetaFieldsRegistry;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;

class MetaFieldExternalTypeValidator extends ConstraintValidator
{
    /**
     * @param MetaFieldRuleEntity|mixed $value
     * @param Constraint $constraint
     */
    public function validate($value, Constraint $constraint): void
    {
        if (!($constraint instanceof MetaFieldExternalType)) {
            throw new UnexpectedTypeException($constraint, MetaFieldExternalType::class);
        }

        if ($value === null) {
            return;
        }

        if (!\is_string($value) || !\in_array($value, MetaFieldsRegistry::getAllExternalNames())) {
            $this->context->buildViolation('Unknown entity type, expected one of: ' . implode(', ', MetaFieldsRegistry::getAllExternalNames()))
                ->atPath('name')
                ->setTranslationDomain('validators')
                ->setCode(MetaFieldEntityType::UNKNOWN_TYPE)
                ->addViolation();
        }
    }
}
