<?php

/*
 * This file is part of the "Custom fields bundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\MetaFieldsBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

#[\Attribute(\Attribute::TARGET_CLASS)]
class MetaFieldEntityType extends Constraint
{
    public const UNKNOWN_TYPE = 'kimai-meta-field-02';

    /**
     * @var array<string, string>
     */
    protected const ERROR_NAMES = [
        self::UNKNOWN_TYPE => 'Unknown entity type.',
    ];

    public string $message = 'Unknown entity type.';

    public function getTargets(): string|array
    {
        return self::CLASS_CONSTRAINT;
    }
}
